const express = require('express')
const app = express()
const querystring = require('querystring')
const mongodb = require('mongodb')
const {MongoClient} = mongodb
const path = require('path')
// user user

// username
// password

app.get('/',function(req,res){
    res.sendFile(path.resolve('./login.html'))
})

app.post('/register',function(req,res){
    
})

app.post('/login',(req,res)=>{
    var body = ''
    req.on('data',function(chunk){
        body += chunk
        // username=root&password=123456
    })
    req.on('end',function(){
        var {username , password}  = querystring.parse(body)
        MongoClient.connect('mongodb://127.0.0.1:27017',function(error,client){
            if(error){
                res.status(500).send()
                return
            }
            var db = client.db('user')
            var colleciton = db.collection('user')
            colleciton.find({username:username,password:password}).toArray(function(err,result){
                if(err){
                    res.status(500).send()
                    return
                }
                if(result.length === 0){
                    // 找不到
                    res.status(200).send('登录很失败，账号密码啥的都不对！')
                } else {
                    res.status(200).send('登录成功！')
                }
            })
        })
    })
})




app.listen(3000)